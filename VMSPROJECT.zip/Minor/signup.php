<?php
include 'connect.php';


$username=$_POST["username"];
$password=$_POST["password"];
$email=$_POST["email"];

$sql="insert into users (username,password,email) values('$username','$password','$email')";
if(mysqli_query($conn,$sql)){
echo "<script> alert('Record submitted succesfully');</script>";
}
?>
