
<!DOCTYPE html>
<html>
<head>
    <title>Visitor Management System</title>
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   
    <link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" type="text/css" href="dashboard.css"> 
    <link rel="stylesheet" href="style.css">
   
    <style>
        .deleteButton{
         background-color: red;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 5px 10px;
        cursor: pointer;
        font-size: 15px;
        font-weight: bold;  
        }
    </style>



</head>
<body>
    <div class="head">
    <h1>Visitor Management System</h1>
    <?php
      date_default_timezone_set('Asia/Kolkata');
      $timestamp = time();
      $date=date("F d, Y h:i:s A", $timestamp);
      ?>
        <p class="date"><?php echo $date; ?></p>
     
    <p class="admin">Admin</p>

    </div>

    <div class="main-container">
        <div class="side-bar" >
    <ul class="side-list" >
        <li class="side-item"><a href="dashboard.php">Home</a></li>
        <li class="side-item"><a href="visitors.php">Visitor Info</a></li>
        <li class="side-item"><a href="newVisitor.php">New Visitor</a></li>
        <li class="side-item"><a href="deleteVisitor.php">Delete Visitor</a></li>
        <li class="side-item"><a href="updateVisitor.php">Update visitor info</a></li>
    </ul>
    </div>

    <div class="middle">

    <?php
     include 'connect.php';
    $selectQuery = "SELECT * FROM visitorAdd";
    $result = mysqli_query($conn,$selectQuery);
    
?>

    <table  class="table table-striped table-dark  table-width" >
        <thead>
            <tr scope="row">
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope "col">Gender</th>
                <th scope="col">Email</th>
                <th scope="col">Mobile</th>
                <th scope="col">Operation</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($row = mysqli_fetch_assoc($result)){?>
                <tr scope="row">
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['name']?></td>
                    <td><?php echo $row['gender']?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['mobile']; ?></td>
                    <td><a href="db_delete.php?id=<?php echo $row['id'];?>" style='color:white;background-color:red' ><input type="submit" class="deleteButton"  value ="Delete"onclick='return checkdelete()'></a></td>
                <tr>
            <?php }?>
        </tbody>
    </table>




        </div>
    </div>
    <script>
        function checkdelete(){
            return confirm('Are you sure you want to delete this data?');
        }
    </script>
</body>
</html>



