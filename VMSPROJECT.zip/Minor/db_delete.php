<?php
include 'connect.php';

if(isset($_GET['id'])){
    $id=$_GET['id'];


    $deletequery="DELETE FROM `visitoradd` WHERE id=$id";

  if(  mysqli_query($conn,$deletequery)){
        ?>
        <script>
            alert("Deleted Successfully");
        </script>
        <meta http-equiv="refresh" content="0;url=http://localhost/Minor/dashboard.php">
        <?php

    }
    
}
?>