<?php 
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $fullname = $first . " " . $last;

    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];

    if(empty($first) || empty($last) || empty($gender) || empty($email) || empty($mobile)){
            echo"<script>
               alert('Please fill all the fields');
               </script>";
    }
    else{

    include 'connect.php';

    $sql="INSERT INTO `visitorADD` (`name`, `gender`, `email`, `mobile`) VALUES ('$fullname', '$gender', '$email', '$mobile')";
    $result = mysqli_query($conn, $sql);
    if($result){
        echo "<script> alert('Record submitted succesfully');</script>";
        header('location:dashboard.php');

    }
    else{
        echo "<script> alert('Record not submitted');</script>";
    }
}

?>