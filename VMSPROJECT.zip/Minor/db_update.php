<?php
include 'connect.php';

if(isset($_GET['id'])){
    $id=$_GET['id'];
    $selectQuery = "SELECT * FROM visitoradd WHERE id=$id";
    $result = mysqli_query($conn,$selectQuery);
    $row = mysqli_fetch_assoc($result);
    $name=$row['name'];
    $gender=$row['gender'];
    $email=$row['email'];
    $mobile=$row['mobile'];

}

?>


<?php
if(isset($_POST['update_detail'])){
    $nam=$_POST['firstname'];
    $ema=$_POST['email'];
    $gen=$_POST['gender'];
    $mobi=$_POST['mobile'];

    $query = "update visitoradd set name='$nam',gender='$gen',email='$ema',mobile='$mobi' where id=$id";
    $result=mysqli_query($conn,$query);
    if($result){
            ?>
            <script>
                alert(" Record Updated Successfully");
            </script>
            <meta http-equiv="refresh" content="0;url=http://localhost/Minor/dashboard.php">
            <?php
    
        
    }
}
?>

<html>
<head>
<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" type="text/css" href="dashboard.css"> 
    <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="update.css">
</head>
<body>
    

<div class="UpdateBox">
<form action="db_update.php?id=<?php echo $id; ?>" method="post">

    <div class="form-group">
    <input type="text"  name="firstname" placeholder="first name" class="form-control" value= "<?php echo $name;?>" >

    </div>
    <div class="form-wrapper">
        <input type="text" name="email" placeholder="Email Address" class="form-control" value= "<?php echo $email;?>"  >
        <i class="zmdi zmdi-email"></i>
    </div>
    <div class="form-wrapper">
        <select name="gender" id="" class="form-control">
            <option  value="" disabled selected><?php echo $gender;?></option>
            <option  value="male">Male</option>
            <option   value="female">Female</option>
            <option  value="other">Other</option>
        </select>
        <i class="zmdi zmdi-caret-down" style="font-size: 17px"></i>
    </div>
    <div class="form-wrapper">
        <input type="tel" placeholder="Mobile" name="mobile" class="form-control" value= "<?php echo $mobile;?>" >
        <i class="zmdi zmdi-lock"></i>
    </div>
    <input  name="update_detail" type='submit' value ="Update">
    
</form>
</div>
</div>

</body>
</html>