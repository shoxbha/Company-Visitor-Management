

<!DOCTYPE html>
<html>
<head>
    <title>Visitor Management System</title>
   
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    -->
    <link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" type="text/css" href="dashboard.css"> 
    <link rel="stylesheet" href="style.css">




</head>
<body>
    <div class="head">
    <h1>Visitor Management System</h1>
    <?php
      date_default_timezone_set('Asia/Kolkata');
      $timestamp = time();
      $date=date("F d, Y h:i:s A", $timestamp);
      ?>
        <p class="date"><?php echo $date; ?></p>
     
    <p class="admin">Admin</p>

    </div>

    <div class="main-container">
        <div class="side-bar" >
    <ul class="side-list" >
        <li class="side-item"><a href="dashboard.php">Home</a></li>
        <li class="side-item"><a href="visitors.php">Visitor Info</a></li>
        <li class="side-item"><a href="newVisitor.php">New Visitor</a></li>
        <li class="side-item"><a href="deleteVisitor.php">Delete Visitor</a></li>
        <li class="side-item"><a href="updateVisitor.php">Update visitor info</a></li>
    </ul>
    </div>

    <div class="middle">


    <div class="wrapper">
				<form action="db_newVisitor.php" method="post">
					<div class="form-group">
						<input type="text"  name="firstname" placeholder="First Name" class="form-control">
						<input type="text"  name="lastname" placeholder="Last Name" class="form-control">
					</div>
					<div class="form-wrapper">
						<input type="text" name="email" placeholder="Email Address" class="form-control">
						<i class="zmdi zmdi-email"></i>
					</div>
					<div class="form-wrapper">
						<select name="gender" id="" class="form-control">
							<option  value="" disabled selected>Gender</option>
							<option  value="male">Male</option>
							<option   value="femal">Female</option>
							<option  value="other">Other</option>
						</select>
						<i class="zmdi zmdi-caret-down" style="font-size: 17px"></i>
					</div>
					<div class="form-wrapper">
						<input type="tel" placeholder="Mobile" name="mobile" class="form-control">
						<i class="zmdi zmdi-lock"></i>
					</div>
					<button>Add Visitor
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
				</form>
			</div>



    </div>

    </div>
</body>
</html>

