<?php
include 'connect.php';

$password=$_POST["password"];
$email=$_POST["email"];

$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";

$result = mysqli_query($conn, $sql);

  
if($result){
  ?>
      <script>
          alert("Login Successful!");
      </script>
      <meta http-equiv="refresh" content="0;url=http://localhost/Minor/dashboard.php">
      <?php
  }
  else{
    ?>
      <script>
          alert("Invalid Credentials!");
      </script>
      <meta http-equiv="refresh" content="0;url=http://localhost/Minor/index.php">
      <?php

  
  }

?>
