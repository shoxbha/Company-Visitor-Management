<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
   <link rel="stylesheet" type="text/css" href="dashboard.css">
</head>
<body>
    <div class="head">
    <h1>Visitor Management System</h1>
    <?php
      date_default_timezone_set('Asia/Kolkata');
      $timestamp = time();
      $date=date("F d, Y h:i:s A", $timestamp);
      ?>
        <p class="date"><?php echo $date; ?></p>
     
    <p class="admin">Admin</p>

    </div>

    <div class="main-container">
        <div class="side-bar" >
    <ul class="side-list" >
        <li class="side-item"><a href="dashboard.php">Home</a></li>
        <li class="side-item"><a href="visitors.php">Visitor Info</a></li>
        <li class="side-item"><a href="newVisitor.php">New Visitor</a></li>
        <li class="side-item"><a href="deleteVisitor.php">Delete Visitor</a></li>
        <li class="side-item"><a href="updateVisitor.php">Update visitor info</a></li>
    </ul>
    </div>

    <div class="middle">
       <div class="middle-item">
        <p> Number of visitor visited :1</p>
       </div>
       <div  class="middle-item">
        <p>
            Number of visitor visited
        </p>
       </div>
       <div  class="middle-item">
        <p>
            Number of visitor visited
        </p>
       </div>
        
    </div>

    </div>
</body>
</html>
